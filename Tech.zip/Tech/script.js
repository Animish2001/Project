function checkdata()
{
if(document.form1.firstName.value=="") 
{
alert("enter your name please")
return false
}

else if(document.form1.lastName.value==""){
    alert("enter your lastName please")
return false
}
else if(document.form1.age.value=="")
{
    alert("enter your age please")
    return false
    }

    else if(document.form1.city.value=="") 
{
alert("enter your city please")
return false
}

else if(document.form1.number.value=="") 
{
alert("enter your number please")
return false
}
else
{
return true
}
}

